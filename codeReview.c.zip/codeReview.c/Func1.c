//
//  Func1.c
//  codeReview.c
//
//  Created by Group 6 on 9/30/18.
//  Copyright © 2018 Group 6. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "Func1.h"

// Calculates our Characteristic number, when given a string and a pointer
bool characteristic(char numString[], int *c)
{
    // Stores the number up to the '.' to be the characteristic
    char *copy = malloc(strlen(numString) + 1);
    strcpy(copy, numString);
    char *charac = strtok(copy,".");
    
    //If it exists
    //      -> Converts string to int
    if(charac)
    {
        *c = atoi(charac);
        return true;
    }
    // If it does not exits
    else
    {
        return false;
    }
}

// Calculates our Numerator & Denominator number, when given a string and 2 pointers
bool mantissa(char numString[], int *numerator, int *denominator)
{
    // Gets the copy of our string to point to after the '.'
    char *copy = malloc(strlen(numString) + 1);
    strcpy(copy, numString);
    char *numer = strchr(copy,".");
    numer = strtok(NULL, ".");
    
    //Creates a pointer to the numerator to increment
    char *numerPtr = numer;
    //Starts our default denominator to be 1.
    char denom[] = "1";
    // Get the length of our numerator
    int len = strlen(numerPtr);
    
    // Adds a '0' for every placeholder
    for(int i=0;i<len;i++)
    {
        strcat(&denom[i],"0");
    }
    
    // If we correctly calculated our numerator
    //          -> Converts string to int
    if(numer)
    {
        *numerator = atoi(numer);
        *denominator = atoi(denom);
        return true;
    }
    
    // Otherwise, neither exists
    else
    {
        return false;
    }
}
