//
//  main.c
//  codeReview.c
//
//  Created by Group 6 on 9/30/18.
//  Copyright © 2018 Group 6. All rights reserved.
//
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include "Func1.h"

int main()
{
    // Creates our variables
    char number[] = "123.00456";
    int c, n, d;
    
    // Calls our functions
    characteristic(number, &c);
    mantissa(number, &n, &d);
    
    //Displays our output
    printf("This is our 'c' (characteristic) number: %d\n", c);
    printf("This is our 'n' (numerator) number: %d\n", n);
    printf("This is our 'd' (denominator) number: %d\n", d);
}
