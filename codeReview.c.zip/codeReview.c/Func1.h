//
//  Func1.h
//  codeReview.c
//
//  Created by Group 6 on 9/30/18.
//  Copyright © 2018 Group 6. All rights reserved.
//

#ifndef Header_h
#define Header_h

//Defines our Functions
bool characteristic(char numString[], int *c);
bool mantissa(char numString[], int *numerator, int *denominator);

#endif /* Header_h */
